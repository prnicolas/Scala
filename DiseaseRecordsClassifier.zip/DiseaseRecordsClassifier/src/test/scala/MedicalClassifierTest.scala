/**
 * Created by Patrick Nicolas on 1/7/2016.
 */
import org.apache.spark.{SparkContext, SparkConf}


object MedicalClassifierTest extends App {
	import MedicalClassifier._

	// Number of tasks (also number of Spark partitions) with the recommended ratio
	// Two tasks per CPU core
	val numTasks: Int = 16
	val conf = new SparkConf().setAppName("MedicalClassification").setMaster(s"local[$numTasks]")
	implicit val sc = new SparkContext(conf)
	sc.setLogLevel("ERROR")

	// The training set
	val trainingSets = ("training/positive", "training/negative")
	// Training
	train(trainingSets, Some( (n: Int, m: Int) => { 	if(n % 220 == 0)  	println(s"    ${n*100.0/m} %")  } )) match {
		case Some(classificationModel) => {
			// Validation sets
			val validationSets = ("training/positive", "training/negative")
			// Validation
			val metricStr = validate(classificationModel, validationSets).map( _.toString)
			if ( metricStr.isDefined )
				println(s" Validation metrics: ${metricStr.get}")
		}
		case None => println("Medical classification failed")
	}

	sc.stop
}

// ----------------------------------  EOF -----------------------------------------------