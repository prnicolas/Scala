/**
 * Created by Patrick Nicolas on 1/7/2016.
 */
import org.apache.spark.mllib.feature.Normalizer
import org.apache.spark.rdd.RDD
import org.apache.spark.mllib.linalg.Vector


	/**
	 * Transformation that implement the normalization of the Tf-Idf observations vector.
	 * The normalization is a simple alternative to the Z-score Standard scaler and
	 * is optional.
	 * Note: The vector can be either Dense or Sparse, although it is very likely that
	 * the vector of observations will be sparce
	 * @param input_rdds  Input RDD of computed Tf-Idf values vector
	 */
class FieldNormalizer(input_rdds: (RDD[Vector], RDD[Vector])) extends  DataTransform[ (RDD[Vector], RDD[Vector]) ] {
	private[this] val scaler = new Normalizer

	def get(tFreq: Vector): Option[Vector] = Some( scaler.transform(tFreq) )

	/**
	 * Normalize the vector of Tf-Idf value associated to each term
	 * @return Normalized tf-Idf data
	 */
	val model: Option[(RDD[Vector], RDD[Vector])] = execute {
		(scaler.transform(input_rdds._1), scaler.transform(input_rdds._2) )
	}
}

// --------------------------------------  EOF --------------------------------------------------------