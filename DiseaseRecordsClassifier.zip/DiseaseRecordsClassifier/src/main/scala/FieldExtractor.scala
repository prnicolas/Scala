/**
 * Created by Patrick Nicolas on 1/7/2016.
 */
import org.htmlcleaner.HtmlCleaner

		/**
		 * Class that extracts contents from an HTML file according to two type tag Selectors.
		 * The loading of training files and the extraction of their content relies on a parallelized array. The execution is therefore
		 * distributed across the multiple CPU core of a single driver machine.
		 * However the implementation does not support distribution on multiple servers. An alternative approach in the case
		 * of very large training set would be to stream the content of the file and generate sequence of RDDs.
		 * {{{
		 *    Extraction using a tuple (tag type, class type, attribute name) (i.e.  <div .. class="class", id="id">)
		 *    Extraction using a single tag (i.e. <p>)
		 * }}}
		 * @param textByClass  List of extractor using a tuple HTML selector
		 * @param textByTag List of HTML tags
		 * @param pathNames  path for the training set to be loaded
		 * @see http://htmlcleaner.sourceforge.net
		 */
final class FieldExtractor(
		textByClass: List[(String, String, String)],
		textByTag: List[String],
		pathNames: (String, String),
		progress:  Option[(Int, Int) => Unit]) extends DataTransform[(List[String], List[String])] {
	import java.io.File

	require(textByClass.nonEmpty || textByTag.nonEmpty, "Fields selector for Field extractor are undefined")

	def this(textByTag: List[String], pathNames: (String, String), monitor:  Option[(Int, Int) => Unit]) =
		this(List.empty[(String, String, String)], textByTag, pathNames, monitor)

	def this(textByTag: List[String], pathNames: (String, String)) =
		this(List.empty[(String, String, String)], textByTag, pathNames, None)

	private[this] val htmlCleaner = new HtmlCleaner

			/**
			 * Extract the content of a single record
			 * @return Extracted content
			 */
	def get(record: String): Option[String] =  extract(new File(record))

			/**
			 * Method to load HTML file and extract their relevant content using a parallelized immutable array
			 * @return  Array of documents of content if extraction succeeded, None otherwise
			 */
	val model:  Option[(List[String], List[String])] = {
		println("  Phase extraction")

		val set1 = extractAll(pathNames._1)
		if (set1.nonEmpty) {
			val set2 = extractAll(pathNames._2)
			if (set2.nonEmpty) Some((set1, set2)) else None
		}
		else None
	}

	private def extractAll(pathName: String): List[String] = {
		val directory = new File(pathName)

		if( directory.isDirectory ) {
			val files: Array[File] = directory.listFiles
			var cnt: Int = 0
				// Convert the array of files into a parallel array for concurrent processing
			files.par.flatMap{ f => {
				if( progress.isDefined ) {
					cnt += 1
					progress.get(cnt, files.size)
				}
				extract(f)
			}} .toList
		}
		else List.empty[String]
	}


	private def extract(file: File): Option[String] = {
		if(file.canRead ) {
			val rootElement = htmlCleaner.clean(file)
			val collector = new StringBuilder

				// Extract the content of a tag with a class and identifier (i.e. <div  class="myCLass"  id="myId">
			if( textByClass.nonEmpty  ) {
				val contentByClass: String = textByClass.map(keys => (rootElement.getElementsByName(keys._1, true), keys._2, keys._3))
					.map(prop => prop._1.map(p => (p, p.getAttributeByName(prop._2)))
					.filter { case (p, cType) => cType != null && cType.equals(prop._3) }.map{ _._1.getText.toString }
					).mkString(" ")
				collector.append(contentByClass)
			}
				// Extract the content from a single HTML tag (i.e <p>, <ol>, ...)
			if (textByTag.nonEmpty) {
				val contentByTag = textByTag.map(
					rootElement.getElementsByName(_, true).map(_.getText.toString).mkString(" ")
				).mkString(" ")
				collector.append(contentByTag)
			}
			Some( collector.toString )
		}
		else None
	}
}



// --------------------------------  EOF -------------------------------------------