import org.apache.spark.SparkContext
import org.apache.spark.mllib.linalg.{SparseVector, DenseVector, Vector}
import org.apache.spark.rdd.RDD

/**
 * Created by Patrick Nicolas on 1/09/2016.
 */

	/**
	 * A very simple pre-processing class to load training and validation set,
	 * extract relevant content from HTML pages, apply text cleaning algorithm
	 * and generate normalized relative term frequenceies
	 */
class PreProcessor {
	import  MedicalClassifier._

	var extractor: FieldExtractor = _
	var cleanser: FieldCleanser = _
	var analyzer: FieldFrequencyAnalyzer = _
	var normalizer: FieldNormalizer = _

	/**
	 * Execute the pre-processing of two classes of records (HTML files) defined
	 * by their respective path
	 * @param trainingSetPath Pair of paths for the positive and negative cases
	 * @param monitor Optional monitoring method of type (Int, Int) => {} for debugging purpose
	 * @param sc  Reference to the implicit Spark context
	 * @return The pair of normalized term frequencies for positive and negative cases
	 */
	def execute(
			trainingSetPath: (String, String),
			monitor: Option[(Int, Int) => Unit] = None)
				  (implicit sc: SparkContext): Option[(RDD[Vector], RDD[Vector])] = for {

		trainContent <- {
			extractor = new FieldExtractor(List[String]("p", "ol"), trainingSetPath, monitor)
			extractor.model
		}
		cleanContent <- { cleanser = new FieldCleanser(trainContent); cleanser.model }
		stats <- { analyzer = new FieldFrequencyAnalyzer(cleanContent); analyzer.model }
		normStats <- { normalizer = new FieldNormalizer(stats); normalizer.model }
	} yield {
			// Just for debugging purpose, to dump a subset of intermediate results
			if( debug ) {
				println(s"   Debug: Extraction\n${trainContent._1.head}}\n ........ ")
				println(s"   Debug: Cleaning\n${cleanContent._1.first.mkString("\n")}\n ........ ")
				stats._1.first match {
					case v: DenseVector =>
						println(s"    Debug Terms frequencies ${v.values.take(10).mkString(", ")} .... ")
					case v: SparseVector =>
						println(s"    Debug Terms frequencies ${v.indices.take(10).mkString(", ")} ...\n${v.values.take(10).mkString(", ")} ...")
				}
			}
			normStats
		}

		/**
		 * Method to pre-process a single record (i.e. HTML file)
		 * @param record  record or name of the HTML file to process
		 * @return  Vector of normalized term frequencies
		 */
	def execute(record: String): Option[Vector] = for {
		content <- extractor.get(record)
		cleanContent <- cleanser.get(content)
		tFreqs <- analyzer.get(cleanContent)
		normTFreqs <- normalizer.get(tFreqs)
	} yield normTFreqs
}

// ----------------------------------------------------  EOF --------------------------------------------------------
