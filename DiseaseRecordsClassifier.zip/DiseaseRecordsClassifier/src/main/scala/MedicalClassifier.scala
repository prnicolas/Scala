/**
 * Created by Patrick Nicolas on 1/7/2016.
 */
import org.apache.spark.mllib.classification.ClassificationModel
import org.apache.spark.mllib.evaluation.BinaryClassificationMetrics
import org.apache.spark.SparkContext

			/**
			 * Singleton that implements the binomial classification of medical/non-medical terms. The
			 * main functions are
			 * {{{
			 *    training  train
			 *    predicting  predict
			 *    validating validate
			 * }}}
			 * The client code is responsible for selecting the appropriate training and validation set from
			 * the original raw data using K-fold splits for instance.
			 */
object MedicalClassifier  {
	var debug = false
	val preProcessor = new PreProcessor
	final val NO_FEATURE_SELECTION = -1
		/**
		 * Generic training method with
		 * @param trainingSetPath  Pair of path for the positive and negative test case HTML records
		 * @param monitor	Optional progress function
		 * @param numReducedFeatures Number of the most relevant features extracted through the Chi-Square test and to be used in the classifier
		 * @param sc	Implicit spark context
		 * @return	Classification model is training succeeds, None otherwise
		 */
	def train(
			trainingSetPath: (String, String),
			monitor: Option[(Int, Int) => Unit] = None,
			numReducedFeatures: Int = NO_FEATURE_SELECTION)
				(implicit sc: SparkContext): Option[ClassificationModel] = {

			println("\nTraining =============== ")
			preProcessor.execute(trainingSetPath, monitor)
				.flatMap(new FieldNaiveBayesClassifier(_, numReducedFeatures).model)
		}
		/**
		 * Classify a record (i.e. HTML file) using a model generated through training
		 * @param model Classification model generated through training
		 * @param record record or HTML file to classify
		 * @return Classification value 1.0 for positive class, 0.0 for negative class
		 */
	def predict(model: ClassificationModel, record: String): Option[Double] =
			preProcessor.execute(record).map( model.predict( _))

		/**
		 * Validation routine that compute the receiver operating characteristics (ROC), the
		 * area below the ROC (in the False positive-False negative chart) and the precision
		 * and recall.
		 * @param model Model extracted from the training
		 * @param validationSetPath   Validation set as a pair of path to the positive and negative cases
		 * @param sc Spark context
		 * @return Validation metrics instance
		 */
	def validate(
			model: ClassificationModel,
			validationSetPath: (String, String))(implicit sc: SparkContext): Option[ValidationMetrics] = {

		println("\nValidation =============== ")
				// Applies the pre-processing and generates predicted values
		val r = preProcessor.execute(validationSetPath)
			.map { case (pos, neg) => (pos.map(x => (model.predict(x), 1.0)),
			neg.map(x => (model.predict(x), 0.0)))
		}
			// Apply the binary classification
		r.map(rdds => rdds._1 ++ rdds._2)
			.map(new BinaryClassificationMetrics(_))
			.map(m => ValidationMetrics(m.roc.collect, m.areaUnderROC, m.pr.collect))
	}
}

// ----------------------------  EOF ------------------------------------------------------------------