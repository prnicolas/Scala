/**
 * Created by Patrick Nicolas on 1/8/2016.
 */

import org.apache.spark.mllib.feature.{IDF, IDFModel}
import org.apache.spark.mllib.linalg.Vector
import org.apache.spark.rdd.RDD


			/**
			 * Class that implements the TF-IDF computation used in the vector space classificaiotn
			 * @param df  RDD of sequence of terms to be analyzed.
			 */
final class FieldFrequencyDocAnalyzer(df: (RDD[List[String]], RDD[List[String]]) ) extends  FieldFrequencyAnalyzer(df) {

	private var idfModels: (IDFModel, IDFModel)  = _
		/**
		 * Transformation that implement the sequential computation of term frequency and the
		 * inverse document frequency to extract the more relevant word
		 * @return RDD of features vectors
		 */
	override val model:  Option[(RDD[Vector], RDD[Vector])] = execute {
		// Process the term frequency across all documents (paragraph of in HTML files)
		val tFreqs: (RDD[Vector], RDD[Vector]) =  ( tf.transform(df._1).cache, tf.transform(df._2).cache)

		// Compute the inverse of the document frequency to remove  very common terms
		val idfProcessor = new IDF
		idfModels = (idfProcessor.fit(tFreqs._1), idfProcessor.fit(tFreqs._2) )
		val vec_rdd1: RDD[Vector] = idfModels._1.transform(tFreqs._1)
		val vec_rdd2: RDD[Vector] = idfModels._2.transform(tFreqs._2)

		(vec_rdd1, vec_rdd2)
	}
}


// -------------------------------------  EOF --------------------------------------------------------------