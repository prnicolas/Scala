/**
 * Created by Patrick Nicolas on 1/7/2016.
 */
import scala.util.{Try, Success, Failure}

		/**
		 * Generic data transformation which is independent from the type of classifier.
		 *  The classifier model are immutable: They are automatically generated when the
		 *  classifier class is instantiated so the life cycle is simple. The model is either completely
		 *  generated through training or does not exist (None)
		 * The type of transformations are
		 * {{{
		 *    Loading files and extracting text from HTML pages
		 *    Cleansing content from stop words, special characters....
		 *    Computing the relative term frequencies
		 *    Computing the tf-idf weights for vector features
		 *    Normalize relative term frequencies or tf-idf weights
		 *    Train a model given a classifier
		 * }}}
		 * @tparam T Type of output of the data transformation
		 */
trait DataTransform[T] {
	val model: Option[T]
	protected def execute(t: T): Option[T] = Try {
		println(s"  ${getClass.getName} start")
		t
	}
	match {
		case Success(t) => { println(s"  ${getClass.getName} completed"); Some(t) }
		case Failure(e) => { println(e.toString); e.printStackTrace; None }
	}
}

// ------------------------------------------  EOF ----------------------------------------------