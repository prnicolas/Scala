/**
 * Created by Patrick Nicolas on 1/7/2016.
 */
import org.apache.spark.rdd.RDD
import org.apache.spark.mllib.linalg.Vector


			/**
			 * Implementation of the relative term frequency analyzer to generate raw features to a classifier.
			 * is implemented as a Spark transformation and avoid the unecessary
			 * materialization of the result back to the Driver.
			 * The transformation converts a sequence of terms per document and generate a features vector
			 * with relative term frequencies
			 * @param df  RDD of sequence of terms to be analyzed.
			 */
class FieldFrequencyAnalyzer(df: (RDD[List[String]],RDD[List[String]]))
		extends DataTransform[(RDD[Vector], RDD[Vector])] {
	import org.apache.spark.mllib.feature.{HashingTF}

	protected[this] val tf = new HashingTF

	def get(input: List[String]): Option[Vector] = Some( tf.transform(input) )

		/**
		 * Transformation that implement the sequential computation of term frequency and the
		 * inverse document frequency to extract the more relevant word.
		 * Optional to speed up execution on partition if memory is available
		 * @return RDD of features vectors
		 */
	val model:  Option[(RDD[Vector], RDD[Vector])] = execute {
		// Process the term frequency across all documents (paragraph of in HTML files)
		( tf.transform(df._1), tf.transform(df._2))
	}
}

// -----------------------------------------------  EOF ------------------------------------------------------------
