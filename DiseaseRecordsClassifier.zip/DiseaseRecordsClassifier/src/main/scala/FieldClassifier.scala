/**
 * Created by Patrick Nicolas on 1/7/2016.
 */
import org.apache.spark.mllib.classification.{LogisticRegressionModel, LogisticRegressionWithSGD, NaiveBayes, NaiveBayesModel}
import org.apache.spark.mllib.feature.ChiSqSelector
import org.apache.spark.mllib.regression.LabeledPoint
import org.apache.spark.mllib.linalg.Vector
import org.apache.spark.mllib.evaluation.BinaryClassificationMetrics
import org.apache.spark.rdd.RDD

/**
 * Class that define the basic validation metrics
 * @param roc   Receivers operating characteristics for binomial classification
 * @param areaUnderROC Area under the receivers operating characteristics curve for binomial classification
 * @param pr  Precision/recall curve
 */
case class ValidationMetrics(roc:  Array[(Double, Double)], areaUnderROC: Double, pr: Array[(Double, Double)]) {
	require(roc.length > 0, "ValidationMetrics, ROC curve is undefined")
	require(pr.length > 0, "ValidationMetrics, Precision-Recall curve is undefined")

	override def toString: String =
		s"ROC = ${roc.mkString(",")}\nArea ROC = ${areaUnderROC}\nPrecision Recall ${pr.mkString(",")}"
}

/**
 * Generic classifier used to classification document in binomial mode
 * @author Patrick Nicolas
 * @tparam T  Type representing a classification model such as SVMModel, LogisticRegressionModel...
 */
sealed trait FieldClassifierValidator[T] {
	self: DataTransform[T] =>
		val model: Option[T]

	/**
	 * Basic validation for binomial (2-class) classifier
	 * @param df  RDD of pairs of actual, expected values
	 * @return  Validation metrics
	 */
		def validate(df: RDD[(Double, Double)]): ValidationMetrics = {
			val metrics = new BinaryClassificationMetrics(df)
			ValidationMetrics(metrics.roc.collect, metrics.areaUnderROC, metrics.pr.collect)
		}

		protected def reduce(
				normalizedPos: RDD[Vector],
				normalizedNeg: RDD[Vector],
				numTopFeatures: Int): RDD[LabeledPoint] = {

			// Concatenate positive and negative
			val labeled_rdd  = normalizedPos.map(LabeledPoint(1.0, _)) ++ normalizedNeg.map(LabeledPoint(0.0, _))

			// If reducer is needed for large number of features, then use s simple ChiSquare test reducer that
			// compute the distance (similiarity) between features
			if( numTopFeatures > 0) {
				val reducer = new ChiSqSelector(numTopFeatures)
				val reducerModel = reducer.fit(labeled_rdd)
				val reduced_rdd = labeled_rdd.map(lb => LabeledPoint(lb.label, reducerModel.transform(lb.features))  )
				println("Chi-square test reducer completed")
				reduced_rdd
			}
			else
				labeled_rdd
		}
}

	/**
	 * Wrapper for the binomial classification using the logistic regression. The class has to implement the transform
	 * method related to training set and the validateF1 related to the validation set.
	 * The training has the option to reduce the number of features by comparing
	 * @author Patrick Nicolas
	 * @param normalizedPos Training set (RDD) for positive case/outcome used for generating the logistic regression model
	 * @param normalizedNeg Training set (RDD) for negative case/outcome used for generating the logistic regression model
	 * @param numTopFeatures  Top independent features extracted using the Chi-square features reduction if value > 0
	 */
case class FieldLogisticClassifier(normalizedPos: RDD[Vector], normalizedNeg: RDD[Vector], numTopFeatures: Int)
		extends DataTransform[LogisticRegressionModel]
			with FieldClassifierValidator[LogisticRegressionModel] {

	private[this] val classifier = new LogisticRegressionWithSGD()

		/**
		 * Transformation that gnerates a Naive-Bayes model from the binary training set
		 * @return Naive-Bayes model if training succeeds, None otherwise
		 */
	val model: Option[LogisticRegressionModel] = execute {
			// Concatenate positive and negative
			// If reducer is needed for large number of features, then use s simple ChiSquare test reducer that
			// compute the distance (similiarity) between features
		val reduced_features_labeled_rdd = reduce(normalizedPos, normalizedNeg, numTopFeatures)
			// Run the classifier for training
		classifier.run(reduced_features_labeled_rdd)
	}
}

	/**
	 * Wrapper for the binomial classification using Naive Bayes. The class has to implement the transform
	 * method related to training set and the validateF1 related to the validation set
	 * @author Patrick Nicolas
	 * @param normalizedInput Training set (RDD) for (positive case/outcome, negative case/outcome) pairs used for generating the Naive Bayes model
	 * @param numTopFeatures  Top independent features extracted using the Chi-square features reduction if value > 0
	 */
case class FieldNaiveBayesClassifier(normalizedInput: (RDD[Vector], RDD[Vector]), numTopFeatures: Int)
	extends DataTransform[NaiveBayesModel]
		with FieldClassifierValidator[NaiveBayesModel] {
		// Multinomial NB used as a binary classifier
	private[this] val classifier = new NaiveBayes()

		/**
		 * Transformation that gnerates a Naive-Bayes model from the binary training set
		 * @return Naive-Bayes model if training succeeds, None otherwise
		 */
	val model: Option[NaiveBayesModel] = execute {
		val reduced_features_labeled_rdd = reduce(normalizedInput._1, normalizedInput._2, numTopFeatures)
		classifier.run(reduced_features_labeled_rdd)
	}
}


// ----------------------------------  EOF ---------------------------------------------------------