/**
 * Created by Patrick Nicolas on 1/7/2016.
 */
import org.apache.spark.rdd.RDD
import org.apache.spark.SparkContext


	/**
	 * Input filter using regular expression, stop words removal, conversion to lower case
	 * size of 1-gram,.....
	 * A more robust implementation would support
	 * - Leminization
	 * - Elimination of stop words
	 * - Synonyms and homonyms using WordNet for instance
	 * @param documents Array of document or content associated to each training file
	 * @param sc	Reference to the Spark context
	 */
final class FieldCleanser(documents: (List[String], List[String]))(implicit sc: SparkContext)
		extends DataTransform[(RDD[List[String]], RDD[List[String]])]  {
	require(documents._1.length > 0, "FieldCleanser sequence of documents is undefined")

	final val regex = "[,.:;'\"\\?\\-!\\(\\)\\+\\#\\&\\/\\[\\]\\d+]"


	def get(record: String): Option[List[String]] = Some( transform(record ) )

		/**
		 * Transformation that clean the content of each training HTML file. This is a very
		 * simple (or rustic) implementation
		 * @return RDD of sequence of terms used as input to the Tf-Idf analyzer
		 */
	val model:  Option[(RDD[List[String]], RDD[List[String]])] = execute {
			(createRDD(documents._1), 	createRDD(documents._2) )
	}

	private def createRDD(records: List[String]): RDD[List[String]]  =
		sc.makeRDD(records)
				.map(_.toLowerCase.split(" ") 			// convert lower case
				.map(_.replaceAll(regex, "")) 			// filter by regular expression
				.filter(_.length > 3).toList)  					// filter by word length

	private def transform(record: String): List[String] = {
		record.toLowerCase.split(" ") // convert lower case
			.map(_.replaceAll(regex, "")) // filter by regular expression
			.filter(_.length > 3).toList // filter by word length
	}
}

// ------------------------------------  EOF ---------------------------------------------